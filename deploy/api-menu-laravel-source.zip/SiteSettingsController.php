<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SiteSetting;
use Illuminate\Http\Request;

class SiteSettingsController extends Controller
{
    private function defaultSettings(): array
    {
        return [
            'logoUrl' => '',
            'faviconUrl' => '',
            'restaurantName' => '',
            'restaurantNameAr' => '',
            'restaurantNameEn' => '',
            'phone' => '',
            'theme' => 'light',
            'buttonColor' => '#d7a439',
            'headingColor' => '#10172a',
            'headingFont' => 'Tajawal',
            'bodyFont' => 'Tajawal',
            'heroSlides' => [],
            'offerGroup' => [
                'titleAr' => '',
                'titleEn' => '',
                'productIds' => [],
                'price' => '',
                'isActive' => false,
            ],
            'vipCampaigns' => [],
            'vipCampaign' => [
                'isActive' => false,
                'targetMode' => 'visits',
                'targetTrigger' => 10,
                'targetAmount' => 0,
                'rewardType' => 'product',
                'productRewardId' => '',
                'productRewardTitleAr' => '',
                'productRewardTitleEn' => '',
                'financialDiscountType' => 'percent',
                'percentage' => 10,
                'fixedAmount' => 50,
                'popupTitleAr' => 'شكراً لزيارتك المتكررة!',
                'popupTitleEn' => 'Thank you for returning!',
                'popupBodyAr' => 'في مرتك القادمة ستحصل على هدية خاصة للعملاء المميزين.',
                'popupBodyEn' => 'On your next visit, you will receive a special VIP reward.',
            ],
            'socialLinks' => [
                'facebook' => '',
                'instagram' => '',
                'snapchat' => '',
                'tiktok' => '',
                'youtube' => '',
            ],
        ];
    }

    private function normalize(array $value): array
    {
        $data = $value['value'] ?? $value;
        $defaults = $this->defaultSettings();
        $social = is_array($data['socialLinks'] ?? null) ? $data['socialLinks'] : [];
        $vipCampaign = is_array($data['vipCampaign'] ?? null) ? $data['vipCampaign'] : [];

        return array_replace_recursive($defaults, [
            'logoUrl' => (string) ($data['logoUrl'] ?? ''),
            'faviconUrl' => (string) ($data['faviconUrl'] ?? ''),
            'restaurantName' => (string) ($data['restaurantName'] ?? ''),
            'restaurantNameAr' => (string) ($data['restaurantNameAr'] ?? ''),
            'restaurantNameEn' => (string) ($data['restaurantNameEn'] ?? ''),
            'phone' => (string) ($data['phone'] ?? ''),
            'theme' => ($data['theme'] ?? 'light') === 'dark' ? 'dark' : 'light',
            'buttonColor' => (string) ($data['buttonColor'] ?? $defaults['buttonColor']),
            'headingColor' => (string) ($data['headingColor'] ?? $defaults['headingColor']),
            'headingFont' => (string) ($data['headingFont'] ?? $defaults['headingFont']),
            'bodyFont' => (string) ($data['bodyFont'] ?? $defaults['bodyFont']),
            'heroSlides' => array_values(array_filter(is_array($data['heroSlides'] ?? null) ? $data['heroSlides'] : [])),
            'offerGroup' => [
                'titleAr' => (string) ($data['offerGroup']['titleAr'] ?? ''),
                'titleEn' => (string) ($data['offerGroup']['titleEn'] ?? ''),
                'productIds' => array_values(array_filter(array_map('strval', is_array($data['offerGroup']['productIds'] ?? null) ? $data['offerGroup']['productIds'] : []))),
                'price' => (string) ($data['offerGroup']['price'] ?? ''),
                'isActive' => (bool) ($data['offerGroup']['isActive'] ?? false),
            ],
            'vipCampaigns' => array_values(is_array($data['vipCampaigns'] ?? null) ? $data['vipCampaigns'] : []),
            'vipCampaign' => [
                'isActive' => (bool) ($vipCampaign['isActive'] ?? false),
                'targetMode' => 'visits',
                'targetTrigger' => is_numeric($vipCampaign['targetTrigger'] ?? null) ? (int) $vipCampaign['targetTrigger'] : 10,
                'targetAmount' => 0,
                'rewardType' => ($vipCampaign['rewardType'] ?? 'product') === 'financial' ? 'financial' : 'product',
                'productRewardId' => (string) ($vipCampaign['productRewardId'] ?? ''),
                'productRewardTitleAr' => (string) ($vipCampaign['productRewardTitleAr'] ?? ''),
                'productRewardTitleEn' => (string) ($vipCampaign['productRewardTitleEn'] ?? ''),
                'financialDiscountType' => ($vipCampaign['financialDiscountType'] ?? 'percent') === 'fixed' ? 'fixed' : 'percent',
                'percentage' => is_numeric($vipCampaign['percentage'] ?? null) ? (float) $vipCampaign['percentage'] : 10,
                'fixedAmount' => is_numeric($vipCampaign['fixedAmount'] ?? null) ? (float) $vipCampaign['fixedAmount'] : 50,
                'popupTitleAr' => (string) ($vipCampaign['popupTitleAr'] ?? $defaults['vipCampaign']['popupTitleAr']),
                'popupTitleEn' => (string) ($vipCampaign['popupTitleEn'] ?? $defaults['vipCampaign']['popupTitleEn']),
                'popupBodyAr' => (string) ($vipCampaign['popupBodyAr'] ?? $defaults['vipCampaign']['popupBodyAr']),
                'popupBodyEn' => (string) ($vipCampaign['popupBodyEn'] ?? $defaults['vipCampaign']['popupBodyEn']),
            ],
            'socialLinks' => [
                'facebook' => (string) ($social['facebook'] ?? ''),
                'instagram' => (string) ($social['instagram'] ?? ''),
                'snapchat' => (string) ($social['snapchat'] ?? ''),
                'tiktok' => (string) ($social['tiktok'] ?? ''),
                'youtube' => (string) ($social['youtube'] ?? ''),
            ],
        ]);
    }

    public function show()
    {
        $record = SiteSetting::query()->find('global');
        if (!$record) {
            $created = SiteSetting::query()->create([
                'key' => 'global',
                'value' => $this->defaultSettings(),
            ]);
            return response()->json(['success' => true, 'data' => $this->normalize($created->toArray())]);
        }

        return response()->json(['success' => true, 'data' => $this->normalize($record->toArray())]);
    }

    public function update(Request $request)
    {
        $record = SiteSetting::query()->find('global');
        $current = $record ? $this->normalize($record->toArray()) : $this->defaultSettings();
        $incoming = $request->all();
        $merged = array_replace_recursive($current, is_array($incoming) ? $incoming : []);

        SiteSetting::query()->updateOrCreate(
            ['key' => 'global'],
            ['value' => $this->normalize($merged)]
        );

        return response()->json(['success' => true, 'data' => $this->normalize($merged)]);
    }
}
