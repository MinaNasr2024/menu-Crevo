function e(r){return`EGP ${Number(r??0).toFixed(2)}`}export{e as f};
